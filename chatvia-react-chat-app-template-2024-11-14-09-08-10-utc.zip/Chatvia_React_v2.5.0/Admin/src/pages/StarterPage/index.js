import React from 'react';

function Index(props) {

    document.title = " Starter Page | Chatvia - Responsive Bootstrap 5 Admin Dashboard"
    return (
        <React.Fragment>
            
        </React.Fragment>
    );
}

export default Index;